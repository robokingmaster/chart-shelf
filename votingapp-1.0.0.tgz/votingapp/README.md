# Add new charts into this repository
This file shows the steps to add new chart into this repository

## Create new helm chart
To create new helm chart create its structure via simple helm command. Make sure you have installed helm. 
[Install Helm](https://helm.sh/docs/intro/install/)
```
helm create votingapp
```
## Test Helm chart
Deploy locally to test if its workign as expected
### Deploy using command line with minimal parameters
```
helm install local-votingapp ./votingapp

```

### Deploy using command line paramaters and ingress
```
helm install local-votingapp ./votingapp \
  --set vote.service.type=ClusterIP \
  --set vote.service.port=80 \
  --set vote.replicaCount=2 \
  --set vote.ingress.enabled=true \
  --set vote.hosts.host=votingapp.example.com \
  --set result.service.type=ClusterIP \
  --set result.service.port=80 \
  --set result.replicaCount=2 \
  --set result.ingress.enabled=true \
  --set result.host=votingresult.example.com 

```

### Deploy using command values file
Copy values.yaml file as my_values.yaml. Modify all the required values and add additional annotations if needed.

```
cp values.yaml my_values.yaml

helm install local-votingapp ./votingapp -f my_values.yaml
```

To upgrade
```
helm upgrade local-votingapp ./votingapp
```

To delete
```
helm uninstall local-votingapp
```

## Deploy helm chart
There are multiple ways to deply the delm charts and passed additional configuration pramaters while deploying. For example additional ingress annotation can be provided while deploying this helm chart. [Supported Annotations](https://kubernetes-sigs.github.io/aws-load-balancer-controller/v2.2/guide/ingress/annotations/#annotations)
### From command line

#### Add the Repo to Helm
On any machine, you can now add your repo:
```
helm repo add chartshelf https://robokingmaster.github.io/chart-shelf/
helm repo update

helm repo list
helm search repo chartshelf

$ helm search repo chartshelf
NAME                    CHART VERSION   APP VERSION     DESCRIPTION                                      
chartshelf/votingapp     1.0.0           1.0.0           A Helm chart for deploying votingapp in Kubernetes
$ 
```
### Install Helm Charts
Retrive the values file and update accordingly. 

#### Install using values file
```
helm inspect values chartshelf/votingapp > votingapp.yaml
```
We can also add ACM certificate in annotation as or provide the TLS certificate
```
vote:
  replicaCount: 1
  image: dockersamples/examplevotingapp_vote
  pullPolicy: IfNotPresent
  containerPort: 80
  service:
    type: NodePort
    port: 80
  ingress:
    enabled: False
    className: alb
    annotations: 
      alb.ingress.kubernetes.io/scheme: internet-facing
      alb.ingress.kubernetes.io/target-type: ip
      alb.ingress.kubernetes.io/healthcheck-path: /
      alb.ingress.kubernetes.io/group.name: frontend    
      alb.ingress.kubernetes.io/listen-ports: '[{"HTTPS": 443}]'
      alb.ingress.kubernetes.io/success-codes: "200,302,307"
    hosts:
      - host: castvote.example.com
        paths:
          - path: /
            pathType: Prefix
    tls: []  

result:
  replicaCount: 1
  image: dockersamples/examplevotingapp_result
  pullPolicy: IfNotPresent
  containerPort: 80
  service:
    type: NodePort
    port: 80
    nodePort: 31002
  ingress:
    enabled: False
    className: alb
    annotations: 
      alb.ingress.kubernetes.io/scheme: internet-facing
      alb.ingress.kubernetes.io/target-type: ip
      alb.ingress.kubernetes.io/healthcheck-path: /
      alb.ingress.kubernetes.io/group.name: frontend    
      alb.ingress.kubernetes.io/listen-ports: '[{"HTTPS": 443}]'
      alb.ingress.kubernetes.io/success-codes: "200,302,307"
    hosts:
      - host: voteresult.example.com
        paths:
          - path: /
            pathType: Prefix
    tls: []    

worker:
  image: dockersamples/examplevotingapp_worker
  pullPolicy: IfNotPresent

redis:
  image: redis:alpine
  pullPolicy: IfNotPresent
  containerPort: 6379
  service:
    type: NodePort
    port: 6379
  
db:
  image: postgres:9.4
  pullPolicy: IfNotPresent
  containerPort: 5432
  postgresUser: postgres
  postgresPassword: postgres
  service:
    type: NodePort
    port: 5432
```
Using this values file lets install the helm chart
```
helm install votingapp chartshelf/votingapp --namespace votingapp --values votingapp.yaml
```

#### Install using command line paramaters
```
helm install local-votingapp ./votingapp \
  --set appVersion=v1.0.0 \
  --set service.type=ClusterIP \
  --set service.port=8080 \
  --set replicaCount=2 \
  --set hosts.host=votingapp.example.com \
  --set ingress.annotations."alb\\.ingress\\.kubernetes\\.io/load-balancer-name"="votingapp-alb"

```

### Uninstall Chart
```
helm uninstall votingapp --namespace votingapp
helm repo remove chartshelf
```
### Deploy using terraform
Terraform resource to deploy this chart
```
resource "helm_release" "voting_app" {
  name       = "votingapp"
  repository = "https://robokingmaster.github.io/chart-shelf"
  chart      = "votingapp"  

  set {
    name  = "replicaCount:"
    value = "1"
  }

  set {
    name  = "hosts.host:"
    value = "<Your fully qualified domain name>"
  }

  // Optional - To Enable TLS
  set {
    name  = "ingress.annotations.alb\\.ingress\\.kubernetes\\.io/certificate-arn"
    value = "<Your ACM certificate arn>"
  } 

  // Optional - If your cluster has alb_controller deployed then this will provision ALB"
  set {
    name  = "ingress.annotations.alb\\.ingress\\.kubernetes\\.io/load-balancer-name"
    value = "<Provided ALB name will be used to provision alb>"
  }   

  // Optional - If you already have ALB"
  set {
    name  = "ingress.annotations.alb\\.ingress\\.kubernetes\\.io/group.name"
    value = "<Your group name for ALB>"
  } 

  // Optional - Retrict Inbound Trafic"
  set {
    name  = "ingress.annotations.alb\\.ingress\\.kubernetes\\.io/inbound-cidrs"
    value = "<Comma [,] Seperated cird ranges >"
  }     
}
```